
import pymssql
import tkinter
import tkinter.ttk as ttk
from tkinter import StringVar
from tkinter import IntVar
def delButton(tree):
    x = tree.get_children()
    for item in x:
        tree.delete(item)
def search():
    conn = pymssql.connect(host='127.0.0.1', port='61693', user='sa', password='123456', database='XJK', charset="UTF-8")
    cursor = conn.cursor()  # 获取光标
    sql = 'select * from xjk'
    if len(snovar1.get().strip()) > 0:
        sql = 'select * from xjk where sno = %s'
    print(sql)
    cursor.execute(sql, (snovar1.get().strip()))
    delButton(treeview)
    for row in cursor:
        treeview.insert('', 'end', values=row)

def insert():
    conn = pymssql.connect(host='127.0.0.1', port='61693', user='sa', password='123456', database='XJK', charset="UTF-8")
    cursor = conn.cursor()
    sql = 'insert into xjk values(%s,%s,%d,%s,%s)'
    print(sql)
    cursor.execute(sql, ((snovar2.get().strip()), (snamevar.get().strip()), (moneyvar.get()), (timevar.get().strip()),
                         (wayvar.get().strip())))
    conn.commit()
    delButton(treeview)
def drop():
    conn = pymssql.connect(host='127.0.0.1', port='61693', user='sa', password='123456', database='XJK', charset="UTF-8")
    cursor = conn.cursor()
    sql = 'delete from xjk where sno=%s'
    cursor.execute(sql, (snovar3.get().strip()))
    conn.commit()
    delButton(treeview)

def update():
    conn = pymssql.connect(host='127.0.0.1', port='61693', user='sa', password='123456', database='XJK', charset="UTF-8")
    cursor = conn.cursor()
    sql1 = 'update xjk set sno=%s where sno=%s'
    sql2 = 'update xjk set sname=%s where sno=%s'
    sql3 = 'update xjk set money=%d where sno=%s'
    sql4 = 'update xjk set time=%s where sno=%s'
    sql5 = 'update xjk set way=%s where sno=%s'
    if updatename.get().strip() == '编号':
        cursor.execute(sql1, ((finaldata1.get().strip()), (snovar4.get().strip())))
        conn.commit()
    if updatename.get().strip() == '消费地点':
        cursor.execute(sql2, ((finaldata1.get().strip()), (snovar4.get().strip())))
        conn.commit()
    if updatename.get().strip() == '金额':
        cursor.execute(sql3, ((finaldata1.get()), (snovar4.get().strip())))
        conn.commit()
    if updatename.get().strip() == '时间':
        cursor.execute(sql4, ((finaldata1.get().strip()), (snovar4.get().strip())))
        conn.commit()
    if updatename.get().strip() == '支付方式':
        cursor.execute(sql5, ((finaldata1.get().strip()), (snovar4.get().strip())))
        conn.commit()
        delButton(treeview)

def getstu():
    print('-----')
    conn = pymssql.connect(host='127.0.0.1', port='61693', user='sa', password='123456', database='XJK', charset="UTF-8")
    print(conn)
    print('连接成功!')
    cursor = conn.cursor()
    sql = 'select * from xjk'
    cursor.execute(sql)
    rs = cursor.fetchall()
    print(rs)

if __name__ == '__main__':
    getstu()


def getstu():

    conn = pymssql.connect(host='127.0.0.1', port='61693', user='sa', password='123456', database='XJK', charset="UTF-8")
    cursor = conn.cursor()
    sql = 'select * from xjk'
    if len(namevar.get().strip()) > 0:
     sql = 'select * from student where name like ' + '\'%' + namevar.get().strip() + '%\''
    print(sql)
    cursor.execute(sql)
    delButton(treeview)
    for row in cursor:
      treeview.insert('', 'end', values=row)


if __name__== '__main__' :

    window = tkinter.Tk()
    window.title('小金库')
    window.geometry('1000x500')


stulist_s_Frame = tkinter.Frame(height=500, width=600)  #创建列表分区
stuBtn_Frame = tkinter.Frame(height=500, width=400)     #创建按钮分区
stulist_s_Frame.grid(row=0, column=0)
stuBtn_Frame.grid(row=0, column=1)

columns = ("编号", "时间", "金额", "消费地点", "消费方式")
treeview = ttk.Treeview(stulist_s_Frame, height=18, show="headings", columns=columns)

treeview.column("编号", width=120, anchor='center')
treeview.column("时间", width=120, anchor='center')
treeview.column("金额", width=120, anchor='center')
treeview.column("消费地点", width=120, anchor='center')
treeview.column("消费方式", width=120, anchor='center')

treeview.heading("编号", text="编号")
treeview.heading("时间", text="时间")
treeview.heading("金额", text="金额")
treeview.heading("消费地点", text="消费地点")
treeview.heading("消费方式", text="消费方式")
treeview.place(x=10, y=30, anchor='nw')

labsno1 = tkinter.Label(stuBtn_Frame, text='消费编号：')
labsno2 = tkinter.Label(stuBtn_Frame, text='消费编号：')
labsno3 = tkinter.Label(stuBtn_Frame, text='消费编号：')
labname = tkinter.Label(stuBtn_Frame, text='消费地点：')
labmoney = tkinter.Label(stuBtn_Frame, text='金额：')
labtime = tkinter.Label(stuBtn_Frame, text='时间：')
labway = tkinter.Label(stuBtn_Frame, text='支付方式：')
labsno1.place(x=20, y=55, anchor='nw')
labsno2.place(x=20, y=95, anchor='nw')
labsno3.place(x=20, y=255, anchor='nw')
labname.place(x=20, y=125, anchor='nw')
labmoney.place(x=20, y=155, anchor='nw')
labtime.place(x=20, y=185, anchor='nw')
labway.place(x=20, y=215, anchor='nw')

labsno = tkinter.Label(stuBtn_Frame, text='要修改的消费编号：')
labUname = tkinter.Label(stuBtn_Frame, text='要修改的列名：')
labfdata = tkinter.Label(stuBtn_Frame, text='修改内容：')
labsno.place(x=0, y=325, anchor='nw')
labUname.place(x=0, y=355, anchor='nw')
labfdata.place(x=20, y=385, anchor='nw')

namevar = StringVar()

snovar1 = StringVar() #查询输入

snovar2 = StringVar() #添加输入
snamevar = StringVar()
moneyvar = IntVar()
timevar = StringVar()
wayvar = StringVar()

snovar3 = StringVar() #删除输入

snovar4 = StringVar() #修改输入
updatename = StringVar()
finaldata1 = StringVar()

entrySno = tkinter.Entry(stuBtn_Frame, textvariable=snovar4, width=20) #修改输入框
entryUname = tkinter.Entry(stuBtn_Frame, textvariable=updatename, width=20)
entryfdata = tkinter.Entry(stuBtn_Frame, textvariable=finaldata1, width=20)
entrySno.place(x=100, y=325, anchor='nw')
entryUname.place(x=100, y=355, anchor='nw')
entryfdata.place(x=100, y=385, anchor='nw')

entrySno3 = tkinter.Entry(stuBtn_Frame, textvariable=snovar1, width=20) #查询输入框
entrySno3.place(x=100, y=55, anchor='nw')

entrySno1 = tkinter.Entry(stuBtn_Frame,textvariable=snovar3, width=20) #删除输入框
entrySno1.place(x=100, y=255, anchor='nw')

entrySno2 = tkinter.Entry(stuBtn_Frame, textvariable=snovar2, width=20) #添加输入框
entrySname = tkinter.Entry(stuBtn_Frame, textvariable=snamevar, width=20)
entrytime = tkinter.Entry(stuBtn_Frame, textvariable=timevar, width=20)
entrymoney = tkinter.Entry(stuBtn_Frame, textvariable=moneyvar, width=20)
entryway = tkinter.Entry(stuBtn_Frame, textvariable=wayvar, width=20)
entrySno2.place(x=100, y=95, anchor='nw')
entrySname.place(x=100, y=125, anchor='nw')
entrymoney.place(x=100, y=155, anchor='nw')
entrytime.place(x=100, y=185, anchor='nw')
entryway.place(x=100, y=215, anchor='nw')

stuget_Btn1 = tkinter.Button(stuBtn_Frame, text="获取消费信息", command=getstu)
stuget_Btn2 = tkinter.Button(stuBtn_Frame, text="查询消费信息", command=search)
stuget_Btn3 = tkinter.Button(stuBtn_Frame, text="添加消费信息", command=insert)
stuget_Btn4 = tkinter.Button(stuBtn_Frame, text="删除消费信息", command=drop)
stuget_Btn5 = tkinter.Button(stuBtn_Frame, text="修改消费信息", command=update)
stuget_Btn5.place(x=300, y=380, anchor='nw')
stuget_Btn4.place(x=300, y=250, anchor='nw')
stuget_Btn3.place(x=300, y=210, anchor='nw')
stuget_Btn2.place(x=300, y=50, anchor='nw')
stuget_Btn1.place(x=300, y=10, anchor='nw')
window.mainloop()